#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//estrutura dos pokemons
typedef struct{
    int numero, geracao, total, lendario, hp, ataque, defesa, ataqueEspecial, defesaEspecial, velocidade, taxaCaptura, preEvolucao, posEvolucao;
    char nome[31], cor[15], tipo1[15], tipo2[15];
    float altura, peso;
}Pokemon;

//estrutura da mochila (valor)
typedef struct{
    int pokemochila;
}Mochila;

//Estrutura da coleção (valor)
typedef struct{
    int pokenumero;
}Colecao;

typedef enum{NOVOJOGO=1, CARREGARJOGO, SAIR}Opcoes;

typedef enum{GERACAO=1, TIPO}Filtro;

typedef enum{INSERIRPOKEMON=1, VISUALIZAR, ALTERAREQUIPE, VOLTARMOCHILA}MenuMochila;

typedef enum{INSERIR=1, LISTAR, PESQUISAR, ALTERAR, EXCLUIR, VOLTARCOLECAO}MenuColecao;

typedef enum{INSERIRPOKEDEX=1, LISTARPOKEDEX, PESQUISARPOKEDEX, ALTERARPOKEDEX, EXCLUIRPOKEDEX, VOLTARPOKEDEX}MenuPokedex;

void mostrarTodos(Pokemon pokedex[], int tamanho);

void PesquisarPoke(Pokemon pokedex[], int tamanho);

void alteraPoke(Pokemon pokedex[], int tamanho);

void excluiPoke(Pokemon pokedex[], int tamanho);

void adicionarPoke(Mochila meuTime[], int tamanho);

void mostrarMochila(Mochila meuTime[], Pokemon pokedex[]);

void alteraMochila(Mochila meuTime[], Pokemon pokedex[], int tamanho);

void addColecao(Colecao minhaColecao[], int tamanho, int tamanhoColecao);

void mostrarColecao(Colecao minhaColecao[], Pokemon pokedex[], int tamanhoColecao);

void buscaColecao(Colecao minhaColecao[], Pokemon pokedex[], int tamanhoColecao);

void alteraColecao(Colecao minhaColecao[], int tamanho, int tamanhoColecao);

void excluiColecao(Colecao minhaColecao[], int tamanhoColecao);

void salvarJogador(FILE *arqjogador, Pokemon *pokedex, Colecao *minhaColecao, Mochila meuTime[], int tamanho, int tamanhoColecao, char nickname[]);