#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "type_defs.h"
#include "mensagem.h"

void criaMensagemTexto(JOGO *jogo,
                       int largura,
                       int altura,
                       char *texto,
                       int tamanho_da_fonte,
                       Color cor_da_fonte,
                       Color fundo,
                       char *opcao_1_texto,
                       char *opcao_2_texto,
                       int opcoes_tamanho_fonte,
                       int opcoes_tamanho_fonte_selecionado,
                       Color opcoes_cor_fonte,
                       Color opcoes_cor_fonte_selecionado,
                       Color opcoes_fundo,
                       Color opcoes_fundo_selecionado,
                       int digitavel)
{
    // define a mensagem como somente texto
    jogo->mensagem.somente_texto = 1;

    // insere os dados fornecidos
    jogo->mensagem.dimensoes.x = largura;
    jogo->mensagem.dimensoes.y = altura;
    jogo->mensagem.mensagem_texto = (char*)malloc(strlen(texto));
    strcpy(jogo->mensagem.mensagem_texto, texto);
    jogo->mensagem.mensagem_tamanho_da_fonte = tamanho_da_fonte;
    jogo->mensagem.mensagem_cor_da_fonte = cor_da_fonte;
    jogo->mensagem.mensagem_fundo = fundo;
    jogo->mensagem.opcao_1_texto = (char*)malloc(strlen(opcao_1_texto));
    strcpy(jogo->mensagem.opcao_1_texto, opcao_1_texto);
    jogo->mensagem.opcao_2_texto = (char*)malloc(strlen(opcao_2_texto));
    strcpy(jogo->mensagem.opcao_2_texto, opcao_2_texto);
    jogo->mensagem.opcoes_tamanho_fonte = opcoes_tamanho_fonte;
    jogo->mensagem.opcoes_tamanho_fonte_selecionado = opcoes_tamanho_fonte_selecionado;
    jogo->mensagem.opcoes_cor_fonte = opcoes_cor_fonte;
    jogo->mensagem.opcoes_cor_fonte_selecionado = opcoes_cor_fonte_selecionado;
    jogo->mensagem.opcoes_fundo = opcoes_fundo;
    jogo->mensagem.opcoes_fundo_selecionado = opcoes_fundo_selecionado;
    jogo->mensagem.digitavel = digitavel;

    // verifica se a mensagem possui campo de texto editavel
    if (digitavel == 1)
    {
        // se sim inicia o cursor no cmapo de texto
        jogo->mensagem.cursor_em = 2;
        // e inicia sem texto
        strcpy(jogo->input_do_jogador.texto, "\0");
        jogo->mensagem.quantidade_de_letras = 0;
    }
    else
    {
        // opcao 3 selecionada por padrao
        jogo->mensagem.cursor_em = 3;
    }

    // indica que ainda não houve resposta
    jogo->mensagem.escolha = 2;
    // indica que será o primeiro loop da mensage
    jogo->mensagem.primeiro_loop = 1;
    // marca a mensagem como aberta
    jogo->mensagem.aberta = 1;
};

void criaMensagemImagens(JOGO *jogo)
{
    jogo->mensagem.aberta = 1;
    jogo->mensagem.somente_texto = 0;
};

void atualizaMensagem(JOGO *jogo)
{
    // verifica o input do jogador
    switch (jogo->input_do_jogador.botao_apertado)
    {
    // caso seja seleciona, resgistra como escolha o valor do cursor no momento
    case SELECIONA_AVANCA:
        // avanca apenas se não for o primeiro loop e o cursor não estiver em campo de texto nem não selecionado
        if (jogo->mensagem.primeiro_loop != 1 && jogo->mensagem.cursor_em != 2 && jogo->mensagem.cursor_em != 3)
        {
            // registra a escolha com o valor do cursor
            jogo->mensagem.escolha = jogo->mensagem.cursor_em;
            // verifica se havia menu aguardando resposta
            if (jogo->resposta_para_menu.aguardando_resposta == 1)
            {
                // se sim registra a respota e marca como respondido
                jogo->resposta_para_menu.resposta = jogo->mensagem.escolha;
                jogo->resposta_para_menu.respondido = 1;
            }
            // fecha mensagem
            fechaMensagem(jogo);
            break;
        }

    // caso não foi apertado um botao de acao, verifica se foi apertado o direcional
    default:
        // encerra o primeiro loop
        jogo->mensagem.primeiro_loop = 0;
        switch (jogo->input_do_jogador.direcional_apertado)
        {
        case MOVER_DIREITA:
            // verifica se está na esquerda ou não selecionado
            if (jogo->mensagem.cursor_em == 0 || jogo->mensagem.cursor_em == 3)
            {
                // se estiver muda para a direita
                jogo->mensagem.cursor_em = 1;
            }
            break;
        case MOVER_ESQUERDA:
            // verifica se está na direita ou não selecionado
            if (jogo->mensagem.cursor_em == 1 || jogo->mensagem.cursor_em == 3)
            {
                // se estiver muda para a esquerda
                jogo->mensagem.cursor_em = 0;
            }
            break;
        case MOVER_BAIXO:
            // verifica se está como não selecionado
            if (jogo->mensagem.cursor_em == 3)
            {
                // se estiver muda para o campo de texto
                jogo->mensagem.cursor_em = 2;
            }
            // verifica se está no campo de texto
            if (jogo->mensagem.cursor_em == 2)
            {
                // se estiver muda para a opcao da direita
                jogo->mensagem.cursor_em = 1;
            }
            break;
        case MOVER_CIMA:
            // verifica se está em uma das opções
            if (jogo->mensagem.cursor_em == 0 || jogo->mensagem.cursor_em == 1)
            {
                // se estiver muda para o campo de texto
                jogo->mensagem.cursor_em = 2;
            }
            break;

        // caso não tenha sido apertado nem para direita nem para esquerda apenas encerra sem alterar a posição
        default:
            // verifica se é digitavel
            if (jogo->mensagem.digitavel == 1)
            {
                // captura o input
                int tecla = GetCharPressed();

                // verifica se mais de uma tecla foi apertada durante o frame atual
                while (tecla > 0)
                {
                    // aceita apenas teclas entre 32 a 125
                    if ((tecla >= 32) && (tecla <= 125) && (jogo->mensagem.quantidade_de_letras < 79))
                    {
                        // adiciona a tecla, fazendo cast para char
                        jogo->input_do_jogador.texto[jogo->mensagem.quantidade_de_letras] = (char)tecla;
                        // adiciona o marcardor de final de string
                        jogo->input_do_jogador.texto[jogo->mensagem.quantidade_de_letras + 1] = '\0';
                        // incrementa a quantidade de letras
                        jogo->mensagem.quantidade_de_letras++;
                    }
                    // captura o proximo input
                    tecla = GetCharPressed();
                }

                // verifica se foi pressionado o backspace
                if (IsKeyPressed(KEY_BACKSPACE))
                {
                    // se foi decrementa a quantidade de letras
                    jogo->mensagem.quantidade_de_letras--;
                    // verifica se o numero de letras ficou negativo
                    if (jogo->mensagem.quantidade_de_letras < 0)
                        // se sim altera para 0
                        jogo->mensagem.quantidade_de_letras = 0;
                    // substitui a ultima letra pelo marcador de fim de string
                    jogo->input_do_jogador.texto[jogo->mensagem.quantidade_de_letras] = '\0';
                }
            }        
        break;
    }
    break;
}
}
;

void desenhaMensagem(JOGO jogo)
{
    // atribui o valor padrao de cor do fundo das opcoes
    int tamanho_da_fonte1 = jogo.mensagem.opcoes_tamanho_fonte;
    int tamanho_da_fonte2 = jogo.mensagem.opcoes_tamanho_fonte;
    Color fundo1 = jogo.mensagem.opcoes_fundo;
    Color fundo2 = jogo.mensagem.opcoes_fundo;

    // altera o tamanho e cor para a versão "selecionado" aonde estiver o cursor
    if (jogo.mensagem.cursor_em == 0)
    {
        tamanho_da_fonte1 = jogo.mensagem.opcoes_tamanho_fonte_selecionado;
        fundo1 = jogo.mensagem.opcoes_fundo_selecionado;
    }
    else if (jogo.mensagem.cursor_em == 1)
    {
        tamanho_da_fonte2 = jogo.mensagem.opcoes_tamanho_fonte_selecionado;
        fundo2 = jogo.mensagem.opcoes_fundo_selecionado;
    }

    // fundo da mensagem. (jogo.tamanho_da_janela / 2) - (jogo.mensagem.dimensoes / 2) centraliza a mensagem na tela
    DrawRectangle((jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 2),
                  (jogo.tamanho_da_janela.y / 2) - (jogo.mensagem.dimensoes.y / 2),
                  jogo.mensagem.dimensoes.x,
                  jogo.mensagem.dimensoes.y,
                  jogo.mensagem.mensagem_fundo);
    // fundo da opcao 1
    DrawRectangle((jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 2),
                  (jogo.tamanho_da_janela.y / 2) + (jogo.mensagem.dimensoes.y / 2) - (tamanho_da_fonte1 + 5),
                  jogo.mensagem.dimensoes.x / 2,
                  jogo.mensagem.opcoes_tamanho_fonte + 5,
                  fundo1);
    // fundo da opcao 2
    DrawRectangle((jogo.tamanho_da_janela.x / 2),
                  (jogo.tamanho_da_janela.y / 2) + (jogo.mensagem.dimensoes.y / 2) - (tamanho_da_fonte2 + 5),
                  jogo.mensagem.dimensoes.x / 2,
                  jogo.mensagem.opcoes_tamanho_fonte + 5,
                  fundo2);

    if (jogo.mensagem.somente_texto == 1)
    {
        // atribui o valor padrao de tamanho e cor
        int tamanho_da_fonte1 = jogo.mensagem.opcoes_tamanho_fonte;
        int tamanho_da_fonte2 = jogo.mensagem.opcoes_tamanho_fonte;
        Color cor_da_fonte1 = jogo.mensagem.opcoes_cor_fonte;
        Color cor_da_fonte2 = jogo.mensagem.opcoes_cor_fonte;

        // altera o tamanho e cor para a versão "selecionado" aonde estiver o cursor
        if (jogo.mensagem.cursor_em == 0)
        {
            tamanho_da_fonte1 = jogo.mensagem.opcoes_tamanho_fonte_selecionado;
            cor_da_fonte1 = jogo.mensagem.opcoes_cor_fonte_selecionado;
        }
        else if (jogo.mensagem.cursor_em == 1)
        {
            tamanho_da_fonte2 = jogo.mensagem.opcoes_tamanho_fonte_selecionado;
            cor_da_fonte2 = jogo.mensagem.opcoes_cor_fonte_selecionado;
        }

        // texto da mensagem
        DrawText(jogo.mensagem.mensagem_texto,
                 (jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 2),
                 (jogo.tamanho_da_janela.y / 2) - (jogo.mensagem.dimensoes.y / 2),
                 jogo.mensagem.mensagem_tamanho_da_fonte,
                 jogo.mensagem.mensagem_cor_da_fonte);
        // texto da opcao 1
        DrawText(jogo.mensagem.opcao_1_texto,
                 (jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 2),
                 (jogo.tamanho_da_janela.y / 2) + (jogo.mensagem.dimensoes.y / 2) - (jogo.mensagem.opcoes_tamanho_fonte + 5),
                 tamanho_da_fonte1,
                 cor_da_fonte1);
        // texto da opcao 2
        DrawText(jogo.mensagem.opcao_2_texto,
                 (jogo.tamanho_da_janela.x / 2),
                 (jogo.tamanho_da_janela.y / 2) + (jogo.mensagem.dimensoes.y / 2) - (jogo.mensagem.opcoes_tamanho_fonte + 5),
                 tamanho_da_fonte2,
                 cor_da_fonte2);
    }
    else
    {
    }
    //verifica se possui campo de texto editavel
    if (jogo.mensagem.digitavel == 1)
    {
        // verifica se o cursor está no campo de texto e altera o fundo do campo de texto de acordo
        Color fundo = YELLOW;
        if (jogo.mensagem.cursor_em == 2)
        {
            //campo de texto selecionado para digitar
            fundo = WHITE;
        }
        //fundo
        DrawRectangle((jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 4),
                      (jogo.tamanho_da_janela.y / 2) - (jogo.mensagem.dimensoes.y / 2) + (jogo.mensagem.opcoes_tamanho_fonte * 6),
                      jogo.mensagem.dimensoes.x / 2,
                      jogo.mensagem.dimensoes.y / 3,
                      fundo);
        //texto
        DrawText(jogo.input_do_jogador.texto,
                 (jogo.tamanho_da_janela.x / 2) - (jogo.mensagem.dimensoes.x / 4),
                 (jogo.tamanho_da_janela.y / 2) - (jogo.mensagem.dimensoes.y / 2) + (jogo.mensagem.opcoes_tamanho_fonte * 6),
                 25,
                 BLACK);
    }
};

void fechaMensagem(JOGO *jogo)
{
    //free(jogo->mensagem.mensagem_texto);
    //free(jogo->mensagem.opcao_1_texto);
    //free(jogo->mensagem.opcao_2_texto);
    jogo->mensagem.aberta = 0;
};