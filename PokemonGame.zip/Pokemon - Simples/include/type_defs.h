/* Previne a inclusão duplicada */
#ifndef TYPE_DEFS_H_INCLUDED
#define TYPE_DEFS_H_INCLUDED

#include <stdlib.h>
#include "raylib.h"
//=========================================================================
// INPUT
//=========================================================================
/* Comandos do jogo */
typedef enum COMANDOS_DO_JOGO
{
  MOVER_CIMA = 0,
  MOVER_BAIXO,
  MOVER_ESQUERDA,
  MOVER_DIREITA,
  SELECIONA_AVANCA,
  DESELECIONA_VOLTA,
  ABRIR_POKEDEX,
  ABRIR_MOCHILA,
  RESPOSTA_DE_MENSAGEM,
  SEM_COMANDO
} COMANDOS_DO_JOGO;

/* inputs do jogador */
typedef struct INPUT_DO_JOGADOR
{
  COMANDOS_DO_JOGO direcional_apertado;
  COMANDOS_DO_JOGO direcional_segurando;
  COMANDOS_DO_JOGO botao_apertado;
  COMANDOS_DO_JOGO botao_segurando;
  char texto[80];
} INPUT_DO_JOGADOR;

/* Tecla e funcionalidade atribuida*/
/* inputs do jogador */
typedef struct TECLA
{
  KeyboardKey tecla;
  COMANDOS_DO_JOGO comando;
} TECLA;

/* Mapa de teclas. Configurado para até 12 teclas */
typedef struct MAPA_DE_TECLAS
{
  int quantidade_de_teclas;
  int quantidade_de_teclas_direcionais;
  TECLA teclas[10];
} MAPA_DE_TECLAS;

//=========================================================================
// GAME
//=========================================================================
/* Posições X e Y */
typedef struct POSICAO
{
  // eixo horizontal
  int x;
  // eixo vertical
  int y;
} POSICAO;

/* celulas para o mapa */
typedef struct ITEM_DE_MAPA
{
  // indica se o jogador por passar
  int passavel;
  // area
  Rectangle box;
} ITEM_DE_MAPA;

/* celulas para o mapa */
typedef struct OBSTACULOS
{
  // endereco
  POSICAO endereco;
  // id item
  ITEM_DE_MAPA item;
} OBSTACULOS;

/* mapa */
typedef struct MAPA
{
  // eixo horizontal
  POSICAO tamanho;
  // posicao para desenho
  POSICAO posicao;

  // imagem
  Texture imagem;

  // obstaculos
  OBSTACULOS *obstaculos[];
} MAPA;

//=========================================================================
// MENUS
//=========================================================================
/* Menus do jogo */
typedef enum MENUS
{
  MENU_INICIAL = 0,
  MENU_PRINCIPAL,
  MENU_MOCHILA,
  SUBMENU_MOCHILHA_EQUIPE,
  SUBMENU_MOCHILHA_COLECAO,
  SUBMENU_MOCHILHA_ITENS,
  MENU_POKEDEX,
  MENU_BATALHA,
  SUBMENU_BATALHA_GOLPES,
  SUBMENU_BATALHA_ITENS,
  SUBMENU_BATALHA_POKEMON,
  // quantidade de itens para iterações. Deve ser alterado também no tamanho do array na definição do struct JOGO
  MENUS_QUANTIDADE = 12,
  // marcador de que não há menu aberto. Deve ser um numero maior que o valor MENUS_QUANTIDADE+1
  MENUS_NENHUM = 20,
} MENUS;

/* Estrutura dos itens dos menus*/
typedef struct ITENS_DE_MENU
{
  // texto do menu
  char texto[80];
  // imagem do item
  Texture2D imagem;
  // imagem para quando o item está selecionado
  Texture2D imagem_selecionado;
} ITENS_DE_MENU;

/* Resposta de mensagem para menu*/
typedef struct RESPOSTA_PARA_MENU
{
  // indica se algum menu está aguardando resposta de mensagem. 0 para falso 1 para verdadeiro
  int aguardando_resposta;
  // indica qual menu estava aguardando a resposta
  MENUS menu;
  // registra em qual item do menu estava o cursor quando abriu a mensagem
  int cursor_em;

  // indica se houve a resposta
  int respondido;
  // resposta dada pelo jogador na mensagem
  int resposta;
} RESPOSTA_PARA_MENU;

/* Estrutura dos menus*/
typedef struct MENU
{
  // dados do menu
  MENUS nome;
  // espaçamento entre as linhas
  int entre_linhas;
  // nome do menu
  char titulo[80];
  // quantidade de itens para interações
  int quantidade_de_itens;
  // itens do menu. O tamanho do array deve ser igual ou maior que o número de itens do menu com mais itens
  ITENS_DE_MENU itens[12];
  // registra em qual item está o cursor
  int cursor_em;
  // indica se o menu é apenas de texto ou de imagens. Usado pela função de desenho para escolher entre DrawTexto e DrawTexture
  int somente_texto;

  // infos para desenho
  POSICAO posicao;
  POSICAO dimensoes;
  int borda_do_menu;
  Color fundo_do_menu;
  int tamanho_da_fonte;
  Color cor_da_fonte;
  int borda_dos_itens;
  Color fundo_dos_itens;
  // caso o item esteja selecionado
  int tamanho_da_fonte_selecionado;
  Color cor_da_fonte_selecionado;

} MENU;

/* Itens do menu inicial*/
typedef enum MENU_INICIAL_ITENS
{
  MENU_INICIAL_NOVO_JOGO = 0,
  MENU_INICIAL_CARREGAR_JOGO,
  MENU_INICIAL_SAIR,
} MENU_INICIAL_ITENS;
/* Itens do menu pincipal*/
typedef enum MENU_PRINCIPAL_ITENS
{
  MENU_PRINCIPAL_SALVAR = 0,
  MENU_PRINCIPAL_CARREGAR_JOGO,
  MENU_PRINCIPAL_SAIR,
  MENU_PRINCIPAL_VOLTAR
} MENU_PRINCIPAL_ITENS;
/* Itens do menu mochila*/
typedef enum MENU_MOCHILA_ITENS
{
  MENU_MOCHILA_OPCAO_ITENS = 0,
  MENU_MOCHILA_EQUIPE,
  MENU_MOCHILA_COLECAO
} MENU_MOCHILA_ITENS;
/* Itens do submenu equipe em mochila*/
typedef enum SUBMENU_MOCHILHA_EQUIPE_ITENS
{
  SUBMENU_MOCHILHA_EQUIPE_TROCAR = 0,
  SUBMENU_MOCHILHA_EQUIPE_DADOS_DO_POKEMON
} SUBMENU_MOCHILHA_EQUIPE_ITENS;
/* Itens do submenu itens em mochila*/
typedef enum SUBMENU_MOCHILHA_ITENS_ITENS
{
  SUBMENU_MOCHILHA_ITENS_POKEBOLAS = 0,
  SUBMENU_MOCHILHA_ITENS_OPCAO_ITENS
} SUBMENU_MOCHILHA_ITENS_ITENS;
/* Itens do menu pokedex*/
typedef enum MENU_POKEDEX_ITENS
{
  MENU_POKEDEX_DADOS_DO_POKEMON = 0,
  MENU_POKEDEX_PESQUISAR_POKEMON
} MENU_POKEDEX_ITENS;
/* Itens do menu batalha*/
typedef enum MENU_BATALHA_ITENS
{
  MENU_BATALHA_FUGIR = 0,
  MENU_BATALHA_GOLPES,
  MENU_BATALHA_TROCAR_POKEMON,
  MENU_BATALHA_OPCAO_ITENS
} MENU_BATALHA_ITENS;
/* Itens do submenu golpes em batalha*/
typedef enum SUBMENU_BATALHA_GOLPES_ITENS
{
  SUBMENU_BATALHA_GOLPES_1 = 0,
  SUBMENU_BATALHA_GOLPES_2,
  SUBMENU_BATALHA_GOLPES_3,
  SUBMENU_BATALHA_GOLPES_4
} SUBMENU_BATALHA_GOLPES_ITENS;
/* Itens do submenu itens em batalha*/
typedef enum SUBMENU_BATALHA_ITENS_ITENS
{
  SUBMENU_BATALHA_ITENS_POKEBOLA = 0,
  SUBMENU_BATALHA_ITENS_POCAO
} SUBMENU_BATALHA_ITENS_ITENS;
/* Itens do submenu pokemon em batalha*/
typedef enum SUBMENU_BATALHA_POKEMON_ITENS
{
  SUBMENU_BATALHA_POKEMON_TROCAR = 0
} SUBMENU_BATALHA_POKEMON_ITENS;

//=========================================================================
// MENSAGEM
//=========================================================================
/* Estrutura das mensagems*/
typedef struct MENSAGEM
{
  // marca se a mensagem está aberta. 0 para falso e 1 para verdadeiro
  int aberta;
  // marca se a mensagem é apenas de texto. 0 para falso e 1 para verdadeiro
  int somente_texto;

  // dados da msg principal
  //  texto da msg principal
  char *mensagem_texto;
  int mensagem_tamanho_da_fonte;
  Color mensagem_cor_da_fonte;
  Color mensagem_fundo;

  // texto da opcao 1 (esquerda)
  char *opcao_1_texto;
  Texture2D opcao_1_imagem;

  // texto da opcao 2 (direita)
  char *opcao_2_texto;
  Texture2D opcao_2_imagem;

  // desenho das opcoes
  int opcoes_tamanho_fonte;
  int opcoes_tamanho_fonte_selecionado;
  Color opcoes_cor_fonte;
  Color opcoes_cor_fonte_selecionado;
  Color opcoes_fundo;
  Color opcoes_fundo_selecionado;

  // registra em que opcao esta o cursor. 0 ou 1 para esquerda e direita, 2 para campo de texto, 3 para não selecionado
  int cursor_em;
  // registra a escolha do jogador. 0 ou 1 para escolhas, 2 para não respondido
  int escolha;
  // 0 para falso, 1 para verdadeiro. Marca se é o primeiro loop da mensagem, usado para que a mensagem não interaja com o botao apertado no menu
  int primeiro_loop;

  // registra se a mensagem possui campo digitável. 0 para falso, 1 para verdadeiro
  int digitavel;
  // conta as letras já digitadas
  int quantidade_de_letras;

  // posição para desenho
  POSICAO dimensoes;
} MENSAGEM;

//=========================================================================
// POKEMON
//=========================================================================
typedef struct POKEMON
{
  int numero;
  char nome[50];
  char tipo_1[10];
  char tipo_2[10];
  int total;
  int hp;
  int ataque;
  int defesa;
  int ataque_especial;
  int defesa_especial;
  int velocidade;
  int geração;
  int lendário;
  char cor[10];
  float altura;
  float peso;
  float taxa_de_captura;

  Texture frente;
  Texture costas;
} POKEMON;

//=========================================================================
// POKEDEX
//=========================================================================
typedef struct POKEDEX
{
  int pokemons_por_pagina;
  int cursor_em;

  POSICAO tamanho_dados;
  Color fundo_dados;
  POSICAO tamanho_opcoes;
  Color fundo_pokemon;
  Color fundo_pokemon_selecionado;

  int mostrando_nesta_pagina[7];
  int quantidade_de_pokemons;
  POKEMON pokemon[1000];
} POKEDEX;

//=========================================================================
// MOCHILA
//=========================================================================
typedef struct MOCHILA
{
  char nome[20];
  int equipe;
  int mochila;

  // dados para desenho
  Texture2D imagem;
  POSICAO posicao;
  POSICAO dimensoes;
} MOCHILA;

//=========================================================================
// COLECAO
//=========================================================================
typedef struct POKEMON_CAPTURADO
{
  int id;
  int quantidade;
} POKEMON_CAPTURADO;

typedef struct COLECAO
{
  int quantidade_pokemon;
  POKEMON_CAPTURADO *pokemons;
} COLECAO;
//=========================================================================
// NPC
//=========================================================================
typedef struct NPC
{
  char nome[20];
  int equipe;
  int mochila;

  // dados para desenho
  Texture2D imagem;
  POSICAO posicao;
  POSICAO dimensoes;
} NPC;

//=========================================================================
// JOGADOR
//=========================================================================
typedef struct JOGADOR
{
  char *nome;
  int equipe;
  int colecao;
  int mochila;

  /* estado do movimento
  0 frente
  1 costas
  2 a 6 direita
  7 a 12 esquerda
  */
  int estado_do_movimento;
  // dados para desenho
  /* imagens
  0 frente
  1 costas
  2 a 6 direita
  7 a 12 esquerda
  */
  Texture2D imagem[7];
  POSICAO posicao;
  POSICAO dimensoes;
} JOGADOR;

//=========================================================================
/* Struct que armazena os dados da sessão atual do jogo */
typedef struct JOGO
{
  // indica se o jogo está pausado. 0 falso e 1 verdadeiro
  int pausado;

  // tamanho da janela
  POSICAO tamanho_da_janela;

  // mapa de teclas
  MAPA_DE_TECLAS mapa_de_teclas;
  // registra o ultimo input do jogador
  INPUT_DO_JOGADOR input_do_jogador;

  // o tamanho do array deve ser o mesmo da quantidade de menus na definição do enum MENUS
  MENU menus_do_jogo[10];
  // indica se um menu está aberto
  MENUS menu_aberto;
  // gerencia as respostas solicitadas pelos menus e respondidas nas mensagems
  RESPOSTA_PARA_MENU resposta_para_menu;
  // indica o ultimo menu aberto. Usado para realizar o retorno quando volta de um submenu
  MENUS menu_anterior;

  // mensagem de opcoes
  MENSAGEM mensagem;

  // jogador
  JOGADOR jogador;
  // pokedex
  POKEDEX pokedex;
  // mapa
  MAPA mapa;
  // registra se está no mapa
  int no_mapa;

  // registra se está no processo de criação de jogo. 0 falso 1 verdadeiro
  int criando_novo_jogo;
  // registra a etapa do processo
  int criando_novo_jogo_etapa;
  // registra se está no processo de carregamento de um jogo. 0 falso 1 verdadeiro
  int carregando_jogo;
  // registra a etapa do processo
  int carregando_jogo_etapa;
  // jogador carregado? 0 para falso e 1 para verdadeiro
  int jogador_carregado;
  // nome do jogador carregado
  char *nome_do_jogador_carregado;

} JOGO;
//=========================================================================
#endif