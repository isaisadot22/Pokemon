/* Previne a inclusão duplicada */
#ifndef POKEDEX_H_INCLUDED
#define POKEDEX_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"

void criaPokedex(JOGO *jogo);
void atualizaPokedex(JOGO *jogo);
void desenhaPokedex(JOGO jogo);
void desenhaDadosPokedex(JOGO jogo);

#endif