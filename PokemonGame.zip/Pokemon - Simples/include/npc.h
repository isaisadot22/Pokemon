/* Previne a inclusão duplicada */
#ifndef NPC_H_INCLUDED
#define NPC_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"



#endif