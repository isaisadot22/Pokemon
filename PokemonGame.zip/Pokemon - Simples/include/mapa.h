/* Previne a inclusão duplicada */
#ifndef MAPA_H_INCLUDED
#define MAPA_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"

void criaMapa(JOGO *jogo);
void atualizaMapa(JOGO *jogo);
void desenhaMapa(JOGO jogo);

#endif