/*
    MENU_INICIAL = 0,
    MENU_OPCOES,
    MENU_MOCHILA,
        SUBMENU_MOCHILHA_POKEMON,
        SUBMENU_MOCHILHA_ITENS,
    MENU_POKEDEX,
    MENU_BATALHA,
        SUBMENU_BATALHA_GOLPES,
        SUBMENU_BATALHA_ITENS,
        SUBMENU_BATALHA_POKEMON
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "type_defs.h"
#include "game.h"
#include "menus.h"
#include "mensagem.h"

/**
 * Constrói os menus
 */
void constroiMenus(JOGO *jogo)
{
    //------------- propriedades do menu inical-----------------
    jogo->menus_do_jogo[MENU_INICIAL].nome = MENU_INICIAL;
    jogo->menus_do_jogo[MENU_INICIAL].tamanho_da_fonte = 20,
    jogo->menus_do_jogo[MENU_INICIAL].tamanho_da_fonte_selecionado = 20,
    jogo->menus_do_jogo[MENU_INICIAL].cor_da_fonte = DARKGRAY;
    jogo->menus_do_jogo[MENU_INICIAL].cor_da_fonte_selecionado = BLACK;
    jogo->menus_do_jogo[MENU_INICIAL].entre_linhas = 2;
    strcpy(jogo->menus_do_jogo[MENU_INICIAL].titulo, "Menu Inicial:");

    // indica que os items desse menu contem apenas texto
    jogo->menus_do_jogo[MENU_INICIAL].somente_texto = 1;

    // quantidade de itens do menu, utilizada para comparações. Não pode ser maior que o valor atribuido no tamanho do arrat itens[] dos menus em type_defs.h
    jogo->menus_do_jogo[MENU_INICIAL].quantidade_de_itens = 3;
    // insere os items
    strcpy(jogo->menus_do_jogo[MENU_INICIAL].itens[0].texto, "Novo Jogo");
    strcpy(jogo->menus_do_jogo[MENU_INICIAL].itens[1].texto, "Carregar Jogo");
    strcpy(jogo->menus_do_jogo[MENU_INICIAL].itens[2].texto, "Encerrar jogo");

    // informações para desenho
    // cor de fundo
    jogo->menus_do_jogo[MENU_INICIAL].fundo_do_menu = SKYBLUE;
    // tamanho
    jogo->menus_do_jogo[MENU_INICIAL].dimensoes.x = 400;
    jogo->menus_do_jogo[MENU_INICIAL].dimensoes.y = 300;
    // centraliza horizontalmente
    jogo->menus_do_jogo[MENU_INICIAL].posicao.x = (jogo->tamanho_da_janela.x / 2) - (jogo->menus_do_jogo[MENU_INICIAL].dimensoes.x / 2);
    // centraliza verticalmente
    jogo->menus_do_jogo[MENU_INICIAL].posicao.y = (jogo->tamanho_da_janela.y / 2) - (jogo->menus_do_jogo[MENU_INICIAL].dimensoes.y / 2);

    // inicia com o cursor no primeiro item
    jogo->menus_do_jogo[MENU_INICIAL].cursor_em = 0;
    //-----------------------------------------------------------

    //------------- propriedades principal-----------------------
    jogo->menus_do_jogo[MENU_PRINCIPAL].nome = MENU_PRINCIPAL;
    jogo->menus_do_jogo[MENU_PRINCIPAL].tamanho_da_fonte = 20,
    jogo->menus_do_jogo[MENU_PRINCIPAL].tamanho_da_fonte_selecionado = 20,
    jogo->menus_do_jogo[MENU_PRINCIPAL].cor_da_fonte = DARKGRAY;
    jogo->menus_do_jogo[MENU_PRINCIPAL].cor_da_fonte_selecionado = BLACK;
    jogo->menus_do_jogo[MENU_PRINCIPAL].entre_linhas = 2;
    strcpy(jogo->menus_do_jogo[MENU_PRINCIPAL].titulo, "Menu:");

    // indica que os items desse menu contem apenas texto
    jogo->menus_do_jogo[MENU_PRINCIPAL].somente_texto = 1;

    // quantidade de itens do menu, utilizada para comparações. Não pode ser maior que o valor atribuido no tamanho do arrat itens[] dos menus em type_defs.h
    jogo->menus_do_jogo[MENU_PRINCIPAL].quantidade_de_itens = 3;
    // insere os items
    strcpy(jogo->menus_do_jogo[MENU_PRINCIPAL].itens[0].texto, "Salvar Jogo");
    strcpy(jogo->menus_do_jogo[MENU_PRINCIPAL].itens[1].texto, "Carregar Jogo");
    strcpy(jogo->menus_do_jogo[MENU_PRINCIPAL].itens[2].texto, "Encerrar jogo");
    strcpy(jogo->menus_do_jogo[MENU_PRINCIPAL].itens[3].texto, "Voltar");

    // informações para desenho
    // cor de fundo
    jogo->menus_do_jogo[MENU_PRINCIPAL].fundo_do_menu = SKYBLUE;
    // tamanho
    jogo->menus_do_jogo[MENU_PRINCIPAL].dimensoes.x = 400;
    jogo->menus_do_jogo[MENU_PRINCIPAL].dimensoes.y = 300;
    // centraliza horizontalmente
    jogo->menus_do_jogo[MENU_PRINCIPAL].posicao.x = (jogo->tamanho_da_janela.x / 2) - (jogo->menus_do_jogo[MENU_PRINCIPAL].dimensoes.x / 2);
    // centraliza verticalmente
    jogo->menus_do_jogo[MENU_PRINCIPAL].posicao.y = (jogo->tamanho_da_janela.y / 2) - (jogo->menus_do_jogo[MENU_PRINCIPAL].dimensoes.y / 2);

    // inicia com o cursor no primeiro item
    jogo->menus_do_jogo[MENU_PRINCIPAL].cursor_em = 0;
    //-----------------------------------------------------------
}

// atualiza a posicao do cursor no menu
void atualizaMenu(JOGO *jogo)
{
    // verifica se havia um menu aguardando resposta de mensangem e esta foi respondida
    if (jogo->resposta_para_menu.aguardando_resposta == 1)
    {
        // envia a acao de resposta
        enviaAcaoParaMenu(jogo, RESPOSTA_DE_MENSAGEM);
    }
    // caso não havia menu aguardando resposta segue o fluxo normal
    else
    {
        // verifica qual é o menu atual
        for (int i = 0; i < MENUS_QUANTIDADE; i++)
        {
            if (jogo->menu_aberto == i)
            {
                // verifica se foi apertado um botao de acao
                switch (jogo->input_do_jogador.botao_apertado)
                {
                case SELECIONA_AVANCA:
                    // caso seja seleciona, envia essa acao para o menu
                    enviaAcaoParaMenu(jogo, SELECIONA_AVANCA);
                    break;
                case DESELECIONA_VOLTA:
                    /* code */
                    break;
                // caso não foi apertado um botao de acao, verifica se foi apertado o direcional
                default:
                    switch (jogo->input_do_jogador.direcional_apertado)
                    {
                    case MOVER_BAIXO:
                        // verifica se não está na última posição
                        if (jogo->menus_do_jogo[i].cursor_em != (jogo->menus_do_jogo[i].quantidade_de_itens - 1))
                        {
                            // se não estiver aumenta o index para ir para o próximo item
                            jogo->menus_do_jogo[i].cursor_em++;
                        }
                        break;
                    case MOVER_CIMA:
                        // verifica se não está na primeira posição
                        if (jogo->menus_do_jogo[i].cursor_em != 0)
                        {
                            // se não estiver aumenta o index para ir para o item anterior
                            jogo->menus_do_jogo[i].cursor_em--;
                        }
                        break;
                    default:
                        // caso não tenha sido apertado nem para baixo nem para cima apenas encerra sem alterar a posição
                        break;
                    }
                    break;
                }
                // encerra o loop caso tenha encontrado o menu aberto correspondente
                break;
            }
        }
    }
}

/**
 * Menu Inicial
 */
void menuInicial(JOGO *jogo, COMANDOS_DO_JOGO comando)
{
    switch (comando)
    {
    case SELECIONA_AVANCA:
        switch (jogo->menus_do_jogo[MENU_INICIAL].cursor_em)
        {
        case MENU_INICIAL_NOVO_JOGO:
            // inicia um novo jogo
            novoJogo(jogo);
            break;
        case MENU_INICIAL_CARREGAR_JOGO:
            // carrega um jogo
            carregaJogo(jogo);
            break;
        case MENU_INICIAL_SAIR:
            // cria uma mensagem de confirmacao para o jogador
            criaMensagemTexto(jogo, 300, 150, "Deseja realmente fechar o jogo?", 15, DARKGRAY, LIME, "Sim", "Nao", 15, 20, DARKGREEN, BLACK, YELLOW, BLUE, 0);
            // registra que está aguardando uma resposta da mensagem
            jogo->resposta_para_menu.aguardando_resposta = 1;
            jogo->resposta_para_menu.menu = MENU_INICIAL;
            jogo->resposta_para_menu.cursor_em = jogo->menus_do_jogo[MENU_INICIAL].cursor_em;
            break;
        default:
            break;
        }
        break;
    case RESPOSTA_DE_MENSAGEM:
        switch (jogo->resposta_para_menu.cursor_em)
        {
        case MENU_INICIAL_SAIR:
            // verifica a resposta do jogador
            if (jogo->resposta_para_menu.resposta == 0)
            {
                // caso seja sim, segue para encerrar o jogo
                encerraGame(jogo);
            }
            else
            {
                // caso seja não continua no menu e resgistra que não aguarda mais a resposta
                jogo->resposta_para_menu.aguardando_resposta = 0;
            }
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}

/**
 * Menu Principal
 */
void menuPrincipal(JOGO *jogo, COMANDOS_DO_JOGO comando)
{
    switch (comando)
    {
    case SELECIONA_AVANCA:
        switch (jogo->menus_do_jogo[MENU_PRINCIPAL].cursor_em)
        {
        case MENU_PRINCIPAL_SALVAR:
            // inicia um novo jogo
            salvaJogo(jogo);
            break;
        case MENU_PRINCIPAL_CARREGAR_JOGO:
            // carrega um jogo
            carregaJogo(jogo);
            break;
        case MENU_PRINCIPAL_SAIR:
            // cria uma mensagem de confirmacao para o jogador
            criaMensagemTexto(jogo, 300, 150, "Deseja realmente fechar o jogo?", 15, DARKGRAY, LIME, "Sim", "Nao", 15, 20, DARKGREEN, BLACK, YELLOW, BLUE, 0);
            // registra que está aguardando uma resposta da mensagem
            jogo->resposta_para_menu.aguardando_resposta = 1;
            jogo->resposta_para_menu.menu = MENU_PRINCIPAL;
            jogo->resposta_para_menu.cursor_em = jogo->menus_do_jogo[MENU_PRINCIPAL].cursor_em;
            break;
        case MENU_PRINCIPAL_VOLTAR:
            jogo->menu_aberto = MENUS_NENHUM;
            break;
        default:
            break;
        }
        break;
    case RESPOSTA_DE_MENSAGEM:
        switch (jogo->resposta_para_menu.cursor_em)
        {
        case MENU_PRINCIPAL_SAIR:
            // verifica a resposta do jogador
            if (jogo->resposta_para_menu.resposta == 0)
            {
                // caso seja sim, segue para encerrar o jogo
                encerraGame(jogo);
            }
            else
            {
                // caso seja não continua no menu e resgistra que não aguarda mais a resposta
                jogo->resposta_para_menu.aguardando_resposta = 0;
            }
            break;
        default:
            break;
        }
        break;
    default:
        break;
    }
}

void enviaAcaoParaMenu(JOGO *jogo, COMANDOS_DO_JOGO comando)
{
    // verifica qual é o menu atual e direciona para a função correta
    switch (jogo->menu_aberto)
    {
    case MENU_INICIAL:
        menuInicial(jogo, comando);
        break;
    default:
        break;
    }
};

/* Desenha um menu */
void desenhaMenu(MENU menu)
{
    // desenha o fundo do menu
    DrawRectangle(menu.posicao.x, menu.posicao.y, menu.dimensoes.x, menu.dimensoes.y, menu.fundo_do_menu);
    // desenha o titulo
    DrawText(menu.titulo, menu.posicao.x, menu.posicao.y, menu.tamanho_da_fonte, DARKGRAY);
    // atualiza a altura para o proximo item
    menu.posicao.y += menu.tamanho_da_fonte + menu.entre_linhas + (menu.tamanho_da_fonte / 2);
    // desenha os itens do menu
    desenhaItem(menu);
};

/* Desenha os items do menu */
void desenhaItem(MENU menu)
{
    // repete para todos os itens do menu
    for (int i = 0; i < menu.quantidade_de_itens; i++)
    {
        // desenha o item
        // verifica se o item é o selecionado
        if (i == menu.cursor_em)
        {
            // caso positivo, altera a cor e posição
            DrawText(menu.itens[i].texto, menu.posicao.x + (menu.tamanho_da_fonte_selecionado / 2), menu.posicao.y, menu.tamanho_da_fonte_selecionado, menu.cor_da_fonte_selecionado);
        }
        else
        {
            // caso negativo desenha normal
            DrawText(menu.itens[i].texto, menu.posicao.x, menu.posicao.y, menu.tamanho_da_fonte, menu.cor_da_fonte);
        }

        // atualiza a altura para o proximo item
        menu.posicao.y += menu.tamanho_da_fonte + menu.entre_linhas;
    }
};

/* Fecha o menu */
void fechaMenu(){

};