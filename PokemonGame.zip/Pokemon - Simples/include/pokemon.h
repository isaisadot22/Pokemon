/* Previne a inclusão duplicada */
#ifndef POKEMON_H_INCLUDED
#define POKEMON_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"



#endif