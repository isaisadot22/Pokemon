#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "pokedex.h"

void criaPokedex(JOGO *jogo)
{
    FILE *pokedex;
    pokedex = fopen("resources/pokedex.csv", "r");

    if (!pokedex)
    {
        printf("Can't open file\n");
    }
    else
    {
        int maximo_de_linhas = 1000;
        char buffer[maximo_de_linhas];

        int linha = 0;

        char *string_pointer;

        while (fgets(buffer,
                     maximo_de_linhas,
                     pokedex) != NULL &&
               linha < maximo_de_linhas)
        {
            // pula a primeira linha que contem os titulos
            if (linha != 0)
            {
                int i = linha - 1;
                // navega até a , e adiciona à variável. NULL indica para continuar da onte parou na anterior
                string_pointer = strtok(buffer, ",");
                jogo->pokedex.pokemon[i].numero = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                strcpy(jogo->pokedex.pokemon[i].nome, string_pointer);
                string_pointer = strtok(NULL, ",");
                strcpy(jogo->pokedex.pokemon[i].tipo_1, string_pointer);
                string_pointer = strtok(NULL, ",");
                strcpy(jogo->pokedex.pokemon[i].tipo_2, string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].total = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].hp = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].ataque = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].ataque_especial = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].defesa = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].defesa_especial = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].velocidade = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].geração = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].lendário = atoi(string_pointer);
                string_pointer = strtok(NULL, ",");
                strcpy(jogo->pokedex.pokemon[i].cor, string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].altura = atof(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].peso = atof(string_pointer);
                string_pointer = strtok(NULL, ",");
                jogo->pokedex.pokemon[i].taxa_de_captura = atof(string_pointer);

                // carrega as texturas
                char caminho_frente[100] = "resources/frente/";
                char numero[3];
                itoa(jogo->pokedex.pokemon[i].numero, numero, 10);
                strcat(caminho_frente, numero);
                strcat(caminho_frente, ".png");
                // carrega a imagem ram
                Image img_f = LoadImage(caminho_frente);
                // carrega a textura na vram
                jogo->pokedex.pokemon[i].frente = LoadTextureFromImage(img_f);
                // libera a ram
                UnloadImage(img_f);
            }
            linha++;
        }
        // marca quantos pokemons foram lidos
        jogo->pokedex.quantidade_de_pokemons = linha;
    }
    // fecha o arquivo
    fclose(pokedex);

    jogo->pokedex.cursor_em = 0;
    jogo->pokedex.fundo_dados = YELLOW;
    jogo->pokedex.fundo_pokemon = LIME;
    jogo->pokedex.fundo_pokemon_selecionado = RED;
    jogo->pokedex.pokemons_por_pagina = 7;
    for (int i = 0; i < 7; i++)
    {
        jogo->pokedex.mostrando_nesta_pagina[i] = i;
    }
}

void desenhaPokedex(JOGO jogo)
{
    DrawText("Podekex:", 10, 10, 50, BLACK);

    for (int i = 0; i < jogo.pokedex.pokemons_por_pagina; i++)
    {
        Color fundo_pokemon = jogo.pokedex.fundo_pokemon;
        if (jogo.pokedex.cursor_em == i)
        {
            fundo_pokemon = jogo.pokedex.fundo_pokemon_selecionado;
        }
        int curva;
        switch (i)
        {
        case 0:
            curva = 50;
            break;
        case 1:
            curva = 75;
            break;
        case 2:
            curva = 100;
            break;
        case 3:
            curva = 125;
            break;
        case 4:
            curva = 100;
            break;
        case 5:
            curva = 75;
            break;
        default:
            curva = 50;
            break;
        }

        DrawRectangle(curva,
                      100 + (50 * i),
                      jogo.pokedex.tamanho_opcoes.x,
                      jogo.pokedex.tamanho_opcoes.x,
                      fundo_pokemon);

        DrawTexture(jogo.pokedex.pokemon[jogo.pokedex.mostrando_nesta_pagina[i]].frente,
                    curva,
                    100 + (50 * i),
                    WHITE);
    }
}
void atualizaPokedex(JOGO *jogo){

};
void desenhaDadosPokedex(JOGO jogo){

};