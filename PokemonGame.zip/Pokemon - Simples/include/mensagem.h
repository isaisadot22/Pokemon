/* Previne a inclusão duplicada */
#ifndef MENSAGEM_H_INCLUDED
#define MENSAGEM_H_INCLUDED

#include "raylib.h"
#include "type_defs.h"

void criaMensagemTexto(JOGO *jogo,
                       int largura,
                       int altura,
                       char *texto,
                       int tamanho_da_fonte,
                       Color cor_da_fonte,                       
                       Color fundo,
                       char *opcao_1_texto,
                       char *opcao_2_texto,
                       int opcoes_tamanho_fonte,
                       int opcoes_tamanho_fonte_selecionado,
                       Color opcoes_cor_fonte,
                       Color opcoes_cor_fonte_selecionado,
                       Color opcoes_fundo,
                       Color opcoes_fundo_selecionado,
                       int digitavel);
void criaMensagemImagens(JOGO *jogo);
void atualizaMensagem(JOGO *jogo);
void desenhaMensagem(JOGO jogo);
void fechaMensagem(JOGO *jogo);

#endif