#include <stdlib.h>
#include "raylib.h"
#include "mapa.h"

void criaMapa(JOGO *jogo)
{
    jogo->mapa.tamanho.x = 960;
    jogo->mapa.tamanho.y = 720;

    jogo->mapa.posicao.x = 0;
    jogo->mapa.posicao.y = 0;

    // carrega a imagem ram
    Image img = LoadImage("resources/mapa.png");
    ImageResize(&img, jogo->mapa.tamanho.x, jogo->mapa.tamanho.y);
    // carrega a textura na vram
    jogo->mapa.imagem = LoadTextureFromImage(img);
    // libera a ram
    UnloadImage(img);
};

void atualizaMapa(JOGO *jogo)
{
    // velocidade
    int velocidade = 2;
    if (jogo->input_do_jogador.botao_apertado == ABRIR_POKEDEX)
    {
        jogo->menu_aberto = MENU_POKEDEX;
    }
    else if (jogo->input_do_jogador.botao_apertado == ABRIR_MOCHILA)
    {
        jogo->menu_aberto = MENU_MOCHILA;
    }

    // verifica o input do jogador
    switch (jogo->input_do_jogador.direcional_apertado)
    {
    case MOVER_DIREITA:
        // verifica o estado do movimento
        if (jogo->jogador.estado_do_movimento < 2 || jogo->jogador.estado_do_movimento > 7)
        {
            // se nao era pra direita atribui direita
            jogo->jogador.estado_do_movimento = 2;
        }
        else
        {
            // se era direita verifica onde esta
            for (int i = 2; i < 7; i++)
            {
                if (jogo->jogador.estado_do_movimento == i)
                {
                    if (i == 6)
                    {
                        // se era o ultimo volta para o primeiro
                        jogo->jogador.estado_do_movimento = 2;
                    }
                    else
                    {
                        // senao aumenta em 1
                        jogo->jogador.estado_do_movimento += 1;
                    }
                }
            }
        }
        // verifica se existe mapa o suficiente ate o final da tela
        if ((jogo->mapa.tamanho.x + jogo->mapa.posicao.x) > jogo->tamanho_da_janela.x)
        {
            // se houve rola o mapa
            jogo->mapa.posicao.x -= velocidade;
        }
        else
        {
            // verifica se o jogador está na boda da tela
            if (jogo->jogador.posicao.x < (jogo->tamanho_da_janela.x - 60))
            {
                // se não estiver move o jogador
                jogo->jogador.posicao.x += velocidade;
            }
        }
        break;
    case MOVER_ESQUERDA:
        // verifica o estado do movimento
        if (jogo->jogador.estado_do_movimento < 7 || jogo->jogador.estado_do_movimento > 11)
        {
            // se nao era pra esquerda atribui esquerda
            jogo->jogador.estado_do_movimento = 7;
        }
        else
        {
            // se era direita verifica onde esta
            for (int i = 7; i < 12; i++)
            {
                if (jogo->jogador.estado_do_movimento == i)
                {
                    if (i == 11)
                    {
                        // se era o ultimo volta para o primeiro
                        jogo->jogador.estado_do_movimento = 7;
                    }
                    else
                    {
                        // senao aumenta em 1
                        jogo->jogador.estado_do_movimento += 1;
                    }
                }
            }
        }
        // verifica se existe mapa o suficiente ate o final da tela
        if (jogo->mapa.posicao.x < 0)
        {
            // se houve rola o mapa
            jogo->mapa.posicao.x += velocidade;
        }
        else
        {
            // verifica se o jogador está na boda da tela
            if (jogo->jogador.posicao.x > 20)
            {
                // se não estiver move o jogador
                jogo->jogador.posicao.x -= velocidade;
            }
        }
        break;
    case MOVER_BAIXO:
        // se nao era pra baixo atribui baixo
        jogo->jogador.estado_do_movimento = 0;

        // verifica se existe mapa o suficiente ate o final da tela
        if ((jogo->mapa.tamanho.y + jogo->mapa.posicao.y) > jogo->tamanho_da_janela.y)
        {
            // se houve rola o mapa
            jogo->mapa.posicao.y -= velocidade;
        }
        else
        {
            // se não houver verifica se o jogador esta na borda
            if (jogo->jogador.posicao.y > (jogo->tamanho_da_janela.y - 60))
            {
                // se não estiver move o jogador
                jogo->jogador.posicao.y += velocidade;
            }
        }
        break;
    case MOVER_CIMA:
        // se nao era pra cima atribui cima
        jogo->jogador.estado_do_movimento = 1;

        // verifica se existe mapa o suficiente ate o final da tela
        if (jogo->mapa.posicao.y < 0)
        {
            // se houve rola o mapa
            jogo->mapa.posicao.y += velocidade;
        }
        else
        {
            // se não houver verifica se o jogador esta na borda
            if (jogo->jogador.posicao.y > 20)
            {
                // se não estiver move o jogador
                jogo->jogador.posicao.y -= velocidade;
            }
        }
        break;
    // repe o processo caso esteja segurando o direcional
    default:
        // verifica o input do jogador
        switch (jogo->input_do_jogador.direcional_segurando)
        {
        case MOVER_DIREITA:
            // verifica o estado do movimento
            if (jogo->jogador.estado_do_movimento < 2 || jogo->jogador.estado_do_movimento > 7)
            {
                // se nao era pra direita atribui direita
                jogo->jogador.estado_do_movimento = 2;
            }
            else
            {
                // se era direita verifica onde esta
                for (int i = 2; i < 7; i++)
                {
                    if (jogo->jogador.estado_do_movimento == i)
                    {
                        if (i == 6)
                        {
                            // se era o ultimo volta para o primeiro
                            jogo->jogador.estado_do_movimento = 2;
                        }
                        else
                        {
                            // senao aumenta em 1
                            jogo->jogador.estado_do_movimento += 1;
                        }
                    }
                }
            }
            // verifica se existe mapa o suficiente ate o final da tela
            if ((jogo->mapa.tamanho.x + jogo->mapa.posicao.x) > jogo->tamanho_da_janela.x)
            {
                // se houve rola o mapa
                jogo->mapa.posicao.x -= velocidade;
            }
            else
            {
                // verifica se o jogador está na boda da tela
                if (jogo->jogador.posicao.x < (jogo->tamanho_da_janela.x - 60))
                {
                    // se não estiver move o jogador
                    jogo->jogador.posicao.x += velocidade;
                }
            }
            break;
        case MOVER_ESQUERDA:
            // verifica o estado do movimento
            if (jogo->jogador.estado_do_movimento < 7 || jogo->jogador.estado_do_movimento > 11)
            {
                // se nao era pra esquerda atribui esquerda
                jogo->jogador.estado_do_movimento = 7;
            }
            else
            {
                // se era direita verifica onde esta
                for (int i = 7; i < 12; i++)
                {
                    if (jogo->jogador.estado_do_movimento == i)
                    {
                        if (i == 11)
                        {
                            // se era o ultimo volta para o primeiro
                            jogo->jogador.estado_do_movimento = 7;
                        }
                        else
                        {
                            // senao aumenta em 1
                            jogo->jogador.estado_do_movimento += 1;
                        }
                    }
                }
            }
            // verifica se existe mapa o suficiente ate o final da tela
            if (jogo->mapa.posicao.x < 0)
            {
                // se houve rola o mapa
                jogo->mapa.posicao.x += velocidade;
            }
            else
            {
                // verifica se o jogador está na boda da tela
                if (jogo->jogador.posicao.x > 20)
                {
                    // se não estiver move o jogador
                    jogo->jogador.posicao.x -= velocidade;
                }
            }
            break;
        case MOVER_BAIXO:
            // se nao era pra baixo atribui baixo
            jogo->jogador.estado_do_movimento = 0;

            // verifica se existe mapa o suficiente ate o final da tela
            if ((jogo->mapa.tamanho.y + jogo->mapa.posicao.y) > jogo->tamanho_da_janela.y)
            {
                // se houve rola o mapa
                jogo->mapa.posicao.y -= velocidade;
            }
            else
            {
                // se não houver verifica se o jogador esta na borda
                if (jogo->jogador.posicao.y > (jogo->tamanho_da_janela.y - 60))
                {
                    // se não estiver move o jogador
                    jogo->jogador.posicao.y += velocidade;
                }
            }
            break;
        case MOVER_CIMA:
            // se nao era pra cima atribui cima
            jogo->jogador.estado_do_movimento = 1;

            // verifica se existe mapa o suficiente ate o final da tela
            if (jogo->mapa.posicao.y < 0)
            {
                // se houve rola o mapa
                jogo->mapa.posicao.y += velocidade;
            }
            else
            {
                // se não houver verifica se o jogador esta na borda
                if (jogo->jogador.posicao.y > 20)
                {
                    // se não estiver move o jogador
                    jogo->jogador.posicao.y -= velocidade;
                }
            }
        default:
            // caso não tenha sido apertado nem para direita nem para esquerda apenas encerra sem alterar a posição
            break;
        }
    }
}

void desenhaMapa(JOGO jogo)
{
    DrawTexture(jogo.mapa.imagem,
                jogo.mapa.posicao.x,
                jogo.mapa.posicao.y,
                WHITE);
};