/* Previne a inclusão duplicada */
#ifndef MENUS_H_INCLUDED
#define MENUS_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"

/* Constrói os menus */
void constroiMenus(JOGO *jogo);
/* MENU Inicial */
void menuInicial(JOGO *jogo, COMANDOS_DO_JOGO comando);
/* Atualiza a posição do cursor no menu */
void atualizaMenu(JOGO *jogo);
/* Envia uma ação para um menu */
void enviaAcaoParaMenu(JOGO *jogo, COMANDOS_DO_JOGO comando);
/* Desenha um menu */
void desenhaMenu(MENU menu);
/* Desenha os items do menu */
void desenhaItem(MENU menu);
/* Fecha o menu */
void fechaMenu();


#endif