/* Previne a inclusão duplicada */
#ifndef GAME_H_INCLUDED
#define GAME_H_INCLUDED

#include "raylib.h"
#include "type_defs.h"

/* Inicia o Jogo */
void iniciaGame(JOGO *jogo);
/* Atualiza os dados */
void atualizaGame(JOGO *jogo);
/* Desenha na tela */
void desenha(JOGO jogo);
/* Verifica botões pressionados */
void verificaInput(JOGO *jogo);
/* Toca som */
void tocaSom();
/* Cria um novo jogo */
void novoJogo(JOGO *jogo);
/* Carrega um jogo */
void carregaJogo(JOGO *jogo);
/* Salva o jogo atual*/
void salvaJogo(JOGO *jogo);
/* Encerra o Jogo */
void encerraGame(JOGO *jogo);

#endif