/* Previne a inclusão duplicada */
#ifndef MOCHILA_H_INCLUDED
#define MOCHILA_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"

void criaMochila(JOGO *jogo);
void atualizaMochila(JOGO *jogo);
void desenhaMochila(JOGO jogo);

#endif