/* Previne a inclusão duplicada */
#ifndef JOGADOR_H_INCLUDED
#define JOGADOR_H_INCLUDED

#include <stdlib.h>
#include "type_defs.h"

// constroi o jogador
void constroiJogador(JOGO *jogo);
void desenhaJogador(JOGO jogo);
void atualizaJogador(JOGO *jogo);
#endif