#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "mochila.h"

void criaMochila(JOGO *jogo){

};
void atualizaMochila(JOGO *jogo){

};

void desenhaMochila(JOGO jogo){
    
};