#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "type_defs.h"
#include "jogador.h"

// constroi o jogador
void constroiJogador(JOGO *jogo)
{
    if (jogo->jogador_carregado == 1)
    {
        char caminho[100] = "output/";
        strcat(caminho, jogo->nome_do_jogador_carregado);
        strcat(caminho, ".csv");
        FILE *jogador;
        jogador = fopen(caminho, "r");

        if (!jogador)
        {
            printf("Can't open file\n");
        }
        else
        {
            int maximo_de_linhas = 2;
            char buffer[maximo_de_linhas];

            int linha = 0;

            char *string_pointer;

            while (fgets(buffer,
                         maximo_de_linhas,
                         jogador) != NULL &&
                   linha < maximo_de_linhas)
            {
                // pula a primeira linha que contem os titulos
                if (linha != 0)
                {
                    //  navega até a , e adiciona à variável. NULL indica para continuar da onte parou na anterior
                    string_pointer = strtok(buffer, ",");
                    strcpy(jogo->jogador.nome, string_pointer);
                    string_pointer = strtok(NULL, ",");
                    jogo->jogador.posicao.x = atoi(string_pointer);
                    string_pointer = strtok(NULL, ",");
                    jogo->jogador.posicao.y = atoi(string_pointer);
                }
                linha++;
            }
        }
        // fecha o arquivo
        fclose(jogador);
    }
    else
    {
        jogo->jogador.nome = (char *)malloc(strlen(jogo->nome_do_jogador_carregado));
        strcpy(jogo->jogador.nome, jogo->nome_do_jogador_carregado);
        // posicao inicial do jogador
        jogo->jogador.posicao.x = 400;
        jogo->jogador.posicao.y = 300;
        }

    // carrega a imagem ram
    Image img1 = LoadImage("resources/jogador_frente.png");
    // carrega a textura na vram
    jogo->jogador.imagem[0] = LoadTextureFromImage(img1);
    // libera a ram
    UnloadImage(img1);
    // carrega a imagem ram
    Image img2 = LoadImage("resources/jogador_costas.png");
    // carrega a textura na vram
    jogo->jogador.imagem[1] = LoadTextureFromImage(img2);
    // libera a ram
    UnloadImage(img2);
    // carrega a imagem ram
    // lado direito
    Image img3 = LoadImage("resources/jogador_lado_1.png");
    // carrega a textura na vram
    jogo->jogador.imagem[2] = LoadTextureFromImage(img3);
    // inver e insere na posicao para esquerda
    ImageFlipHorizontal(&img3);
    jogo->jogador.imagem[7] = LoadTextureFromImage(img3);
    // libera a ram
    UnloadImage(img3);
    Image img4 = LoadImage("resources/jogador_lado_2.png");
    // carrega a textura na vram
    jogo->jogador.imagem[3] = LoadTextureFromImage(img4);
    ImageFlipHorizontal(&img4);
    jogo->jogador.imagem[8] = LoadTextureFromImage(img4);
    // libera a ram
    UnloadImage(img4);
    Image img5 = LoadImage("resources/jogador_lado_3.png");
    // carrega a textura na vram
    jogo->jogador.imagem[4] = LoadTextureFromImage(img5);
    ImageFlipHorizontal(&img5);
    jogo->jogador.imagem[9] = LoadTextureFromImage(img5);
    // libera a ram
    UnloadImage(img5);
    Image img6 = LoadImage("resources/jogador_lado_4.png");
    // carrega a textura na vram
    jogo->jogador.imagem[5] = LoadTextureFromImage(img6);
    ImageFlipHorizontal(&img6);
    jogo->jogador.imagem[10] = LoadTextureFromImage(img6);
    // libera a ram
    UnloadImage(img6);
    Image img7 = LoadImage("resources/jogador_lado_5.png");
    // carrega a textura na vram
    jogo->jogador.imagem[6] = LoadTextureFromImage(img7);
    ImageFlipHorizontal(&img7);
    jogo->jogador.imagem[11] = LoadTextureFromImage(img7);
    // libera a ram
    UnloadImage(img7);


    jogo->jogador.estado_do_movimento = 0;
};

void desenhaJogador(JOGO jogo)
{
    DrawTexture(jogo.jogador.imagem[jogo.jogador.estado_do_movimento],
                jogo.jogador.posicao.x,
                jogo.jogador.posicao.y,
                WHITE);
};

void atualizaJogador(JOGO *jogo)
{
};
