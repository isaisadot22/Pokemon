#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "raylib.h"
#include "type_defs.h"
#include "game.h"
#include "menus.h"
#include "mensagem.h"
#include "mapa.h"
#include "pokedex.h"
#include "jogador.h"
#include "mochila.h"

/* Inicia o Jogo */
void iniciaGame(JOGO *jogo)
{
    // configura as teclas. A quantidade deve ser atribuida também na definição do array de teclas do mapa_de_teclas em type_defs.h
    jogo->mapa_de_teclas.quantidade_de_teclas = 10;
    // quantidade de teclas direcionais para ser usado no verificaInput
    jogo->mapa_de_teclas.quantidade_de_teclas_direcionais = 4;
    // direcional. Obs: As teclas de direção são sempre as primeiras do array para que verificaInput() funcione corretamente
    jogo->mapa_de_teclas.teclas[0].tecla = KEY_RIGHT;
    jogo->mapa_de_teclas.teclas[0].comando = MOVER_DIREITA;
    jogo->mapa_de_teclas.teclas[1].tecla = KEY_LEFT;
    jogo->mapa_de_teclas.teclas[1].comando = MOVER_ESQUERDA;
    jogo->mapa_de_teclas.teclas[2].tecla = KEY_UP;
    jogo->mapa_de_teclas.teclas[2].comando = MOVER_CIMA;
    jogo->mapa_de_teclas.teclas[3].tecla = KEY_DOWN;
    jogo->mapa_de_teclas.teclas[3].comando = MOVER_BAIXO;
    // seleciona/avança
    jogo->mapa_de_teclas.teclas[4].tecla = KEY_ENTER;
    jogo->mapa_de_teclas.teclas[4].comando = SELECIONA_AVANCA;
    jogo->mapa_de_teclas.teclas[5].tecla = KEY_A;
    jogo->mapa_de_teclas.teclas[5].comando = SELECIONA_AVANCA;
    // deseleciona/avança
    jogo->mapa_de_teclas.teclas[6].tecla = KEY_S;
    jogo->mapa_de_teclas.teclas[6].comando = DESELECIONA_VOLTA;
    jogo->mapa_de_teclas.teclas[7].tecla = KEY_ESCAPE;
    jogo->mapa_de_teclas.teclas[7].comando = DESELECIONA_VOLTA;
    // abre a pokedex
    jogo->mapa_de_teclas.teclas[8].tecla = KEY_P;
    jogo->mapa_de_teclas.teclas[8].comando = ABRIR_POKEDEX;
    // abre a mochila
    jogo->mapa_de_teclas.teclas[9].tecla = KEY_M;
    jogo->mapa_de_teclas.teclas[9].comando = ABRIR_MOCHILA;

    // define o tamanho padrao da janela
    jogo->tamanho_da_janela.x = 800;
    jogo->tamanho_da_janela.y = 600;

    // constroi os menus do jogo
    constroiMenus(jogo);

    // inicia a janela do jogo
    InitWindow(jogo->tamanho_da_janela.x, jogo->tamanho_da_janela.y, "Pokemon knight!");
    // define a Tecla END para fechar o programa a qualquer momento. Obs: Esc fecha no menu inicial, e nas outras telas funciona como voltar
    SetExitKey(KEY_END);
    // define a taxa de FPS
    SetTargetFPS(60);

    // inicia o jogo sem menus aguardando resposta de mensagems
    jogo->resposta_para_menu.aguardando_resposta = 0;

    // inicia o jogo no menu inicial
    jogo->menu_aberto = MENU_INICIAL;

    // inicia o jogo sem mensagems abertas
    jogo->mensagem.aberta = 0;

    // inicia o jogo sem carregamento de em andamento
    jogo->carregando_jogo = 0;
    jogo->carregando_jogo_etapa = 0;

    // inicia o jogo sem novo jogo em andamento
    jogo->criando_novo_jogo = 0;
    jogo->criando_novo_jogo_etapa = 0;

    // inicia o jogo pausado
    jogo->pausado = 1;
};

/* Atualiza os dados */
void atualizaGame(JOGO *jogo)
{
    // verifica e registra as teclas apertadas
    verificaInput(jogo);

    // verifica se está criando um novo jogo
    if (jogo->criando_novo_jogo == 1)
    {
        novoJogo(jogo);
    }
    // verifica se está carregando um novo jogo
    else if (jogo->carregando_jogo == 1)
    {
        carregaJogo(jogo);
    }
    // verifica se alguma mensagem está aberta
    else if (jogo->mensagem.aberta != 0)
    {
        // caso esteja, atualiza a mensagem
        atualizaMensagem(jogo);
    }
    else
    {
        // verifica se algum menu está aberto. Caso uma mensagem está aberta não será atualizado o menu
        if (jogo->menu_aberto != MENUS_NENHUM)
        {
            if (jogo->menu_aberto == MENU_POKEDEX)
            {
                // caso seka a pokedex
                atualizaPokedex(jogo);
            }
            else if (jogo->menu_aberto == MENU_MOCHILA)
            {
                // caso seka a mochila
                atualizaMochila(jogo);
            }
            else
            { // caso esteja, atualiza o menu
                atualizaMenu(jogo);
            }
        }
        // verifica se está no mapa. Só atualiza o mapa se não houver menu ou mensagens abertas
        else if (jogo->no_mapa == 1)
        {
            atualizaMapa(jogo);
        }
    }
    atualizaJogador(jogo);
};

/* Desenha na tela */
void desenha(JOGO jogo)
{
    // define a cor do fundo para limpeza da tela
    Color cor_de_fundo = BLACK;

    BeginDrawing();
    //-------------
    ClearBackground(cor_de_fundo);
    // verifica se há menu aberto e desenha se houver
    if (jogo.no_mapa != 0)
    {
        desenhaMapa(jogo);
        desenhaJogador(jogo);
    }
    // verifica se há menu aberto e desenha se houver
    if (jogo.menu_aberto != MENUS_NENHUM)
    {
        if (jogo.menu_aberto == MENU_POKEDEX)
        {
            // caso seka a pokedex
            desenhaPokedex(jogo);
        }
        else if (jogo.menu_aberto == MENU_MOCHILA)
        {
            // caso seka a mochila
            desenhaMochila(jogo);
        }
        else
        {
            desenhaMenu(jogo.menus_do_jogo[jogo.menu_aberto]);
        }
    }
    // verifica se há mensagem aberta e desenha se houver
    if (jogo.mensagem.aberta != 0)
    {
        desenhaMensagem(jogo);
    }

    //-------------
    EndDrawing();
};

/* Verifica botões pressionados */
void verificaInput(JOGO *jogo)
{
    // limpa inputs anteriores
    jogo->input_do_jogador.botao_apertado = SEM_COMANDO;
    jogo->input_do_jogador.botao_segurando = SEM_COMANDO;
    jogo->input_do_jogador.direcional_apertado = SEM_COMANDO;
    jogo->input_do_jogador.direcional_segurando = SEM_COMANDO;

    // atualiza o direcional apertado.
    for (size_t i = 0; i < jogo->mapa_de_teclas.quantidade_de_teclas_direcionais; i++)
    {
        if (IsKeyPressed(jogo->mapa_de_teclas.teclas[i].tecla))
        {
            jogo->input_do_jogador.direcional_apertado = jogo->mapa_de_teclas.teclas[i].comando;
        }
    }

    // atualiza o direcional que esta sendo segurado
    for (size_t i = 0; i < jogo->mapa_de_teclas.quantidade_de_teclas_direcionais; i++)
    {
        if (IsKeyDown(jogo->mapa_de_teclas.teclas[i].tecla))
        {
            jogo->input_do_jogador.direcional_segurando = jogo->mapa_de_teclas.teclas[i].comando;
        }
    }

    // atualiza o botao apertado. Inicia o loop após as teclas de direcionais
    for (size_t i = jogo->mapa_de_teclas.quantidade_de_teclas_direcionais; i < jogo->mapa_de_teclas.quantidade_de_teclas; i++)
    {
        if (IsKeyPressed(jogo->mapa_de_teclas.teclas[i].tecla))
        {
            jogo->input_do_jogador.botao_apertado = jogo->mapa_de_teclas.teclas[i].comando;
        }
    }

    // atualiza o botao que esta sendo segurado. Inicia o loop após as teclas de direcionais
    for (size_t i = jogo->mapa_de_teclas.quantidade_de_teclas_direcionais; i < jogo->mapa_de_teclas.quantidade_de_teclas; i++)
    {
        if (IsKeyDown(jogo->mapa_de_teclas.teclas[i].tecla))
        {
            jogo->input_do_jogador.botao_segurando = jogo->mapa_de_teclas.teclas[i].comando;
        }
    }
};

/* Toca som */
void tocaSom(){

};

/*inicia um novo jogo*/
void novoJogo(JOGO *jogo)
{
    switch (jogo->criando_novo_jogo_etapa)
    {
    case 0:
        jogo->criando_novo_jogo = 1;
        criaMensagemTexto(jogo, 800, 300, "A e ENTER: avanca, S e ESC: volta, M: mochila, P: pokedex, Setas: movimento, END: encerra sem salvar", 14, BLACK, LIGHTGRAY, "", "Proseguir...", 15, 20, BLACK, DARKGREEN, LIGHTGRAY, DARKGRAY, 0);
        jogo->criando_novo_jogo_etapa = 1;
        break;
    case 1:
        if (jogo->mensagem.escolha == 2 || jogo->mensagem.escolha == 3)
        {
            atualizaMensagem(jogo);
        }
        else
        {
            criaMensagemTexto(jogo, 600, 300, "Bem vindo ao Pokemon knight! Qual seu nome?", 15, BLACK, LIGHTGRAY, "", "Prosseguir...", 15, 20, BLACK, DARKGREEN, LIGHTGRAY, DARKGRAY, 1);
            jogo->criando_novo_jogo_etapa = 2;
        }
        break;
    case 2:
        if (jogo->mensagem.escolha == 2 || jogo->mensagem.escolha == 3)
        {
            atualizaMensagem(jogo);
        }
        else
        {
            jogo->nome_do_jogador_carregado = (char *)malloc(strlen(jogo->input_do_jogador.texto));
            strcpy(jogo->nome_do_jogador_carregado, jogo->input_do_jogador.texto);
            //---------------------------------------------------
            FILE *save;
            char caminho[100] = "output/";

            strcat(caminho, jogo->nome_do_jogador_carregado);
            strcat(caminho, ".csv");

            save = fopen(caminho, "w");
            fprintf(save, "Nome, posicao_x, posicao_y\n");
            fprintf(save, "%s, %i, %i\n", jogo->nome_do_jogador_carregado, 0, 0);
            fclose(save);
            //---------------------------------------------------
            FILE *mochila;
            char caminho_m[100] = "output/mochila_";

            strcat(caminho_m, jogo->nome_do_jogador_carregado);
            strcat(caminho_m, ".csv");

            mochila = fopen(caminho_m, "w");
            fprintf(mochila, "ID, Nome, posicao_x, posicao_y\n");
            fclose(mochila);
            //---------------------------------------------------
            FILE *colecao;
            char caminho_c[100] = "output/colecao_";

            strcat(caminho_c, jogo->nome_do_jogador_carregado);
            strcat(caminho_c, ".csv");

            colecao = fopen(caminho_c, "w");
            fprintf(colecao, "id_pokemon, quantidade\n");
            fclose(colecao);
            //---------------------------------------------------

            jogo->menu_aberto = MENUS_NENHUM;
            jogo->criando_novo_jogo = 0;

            jogo->carregando_jogo_etapa = 2;
            jogo->mensagem.escolha = 1;
            carregaJogo(jogo);
        }
        break;
    default:
        break;
    }
}

/*carrega um jogo salvo*/
void carregaJogo(JOGO *jogo)
{
    switch (jogo->carregando_jogo_etapa)
    {
    case 0:
        jogo->carregando_jogo = 1;
        criaMensagemTexto(jogo, 600, 300, "Qual jogo deseja carregar?", 15, BLACK, LIGHTGRAY, "", "Proseguir...", 15, 20, BLACK, DARKGREEN, LIGHTGRAY, DARKGRAY, 0);
        jogo->carregando_jogo_etapa = 1;
        break;
    case 1:
        if (jogo->mensagem.escolha == 2 || jogo->mensagem.escolha == 3)
        {
            atualizaMensagem(jogo);
        }
        else
        {
            jogo->jogador_carregado = 1;
            jogo->carregando_jogo_etapa = 2;
        }
        break;
    case 2:
        //---------------------------------------------------
        // cria a pokedex
        criaPokedex(jogo);
        //---------------------------------------------------
        // cria o mapa
        criaMapa(jogo);
        //---------------------------------------------------
        // cria o jogador
        constroiJogador(jogo);
        //---------------------------------------------------

        jogo->no_mapa = 1;
        jogo->menu_aberto = MENUS_NENHUM;
        jogo->carregando_jogo = 0;
    default:
        break;
    }
}
/*salva um novo jogo*/
void salvaJogo(JOGO *jogo)
{
}

/* Encerra o Jogo */
void encerraGame(JOGO *jogo)
{
    // libera a memoria
    for (size_t i = 0; i < jogo->pokedex.quantidade_de_pokemons; i++)
    {
        UnloadTexture(jogo->pokedex.pokemon[i].costas);
        UnloadTexture(jogo->pokedex.pokemon[i].frente);
    }
    UnloadTexture(jogo->mapa.imagem);

    // fecha a janela
    CloseWindow();
};