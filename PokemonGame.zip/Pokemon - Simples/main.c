#include <raylib.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "include/type_defs.h"
#include "include/game.h"
#include "include/menus.h"

int main(void)
{
    // dados do jogo
    JOGO jogo;

    // Inicia o jogo
    iniciaGame(&jogo);

    // Loop principal do jogo. Ativo enquanto o sistema não envia requisão para fecha a janela
    while (!WindowShouldClose())
    {
        // atualiza os dados do jogo
        atualizaGame(&jogo);
        // desenha na tela de acordo com o dados atualizados
        desenha(jogo);
    }

    // encerra o jogo
    encerraGame(&jogo);

    return 0;
}